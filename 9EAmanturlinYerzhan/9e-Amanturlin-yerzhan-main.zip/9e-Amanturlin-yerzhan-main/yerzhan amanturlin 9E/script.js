styledimg {
    background-image:
    background-repeat: no-repeat;
    width: 100 px;
    height: 200 px;
    }